package net.beiker.xletview.classloader;

import javassist.*;

/**
 *
 * @author Martin Sveden
 */
public class EmulatorClassMap extends ClassMap{

	public EmulatorClassMap(){
		
	}

}
