package net.beiker.xletview.util;

/**
 * 
 * @author Martin Sveden
 */
public class Logger {

	public Logger(){
		
	}
	
	public void debug(Object object){
		System.out.println("" + object);
	}
	
	public void error(Object object){
		System.out.println("" + object);
	}
	
}
