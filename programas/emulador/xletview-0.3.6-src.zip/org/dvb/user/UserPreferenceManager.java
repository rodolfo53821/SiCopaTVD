/*

 This file is part of XleTView 
 Copyright (C) 2003 Martin Sved�n
 
 This is free software, and you are 
 welcome to redistribute it under 
 certain conditions;

 See LICENSE document for details.

*/


package org.dvb.user ;

import java.io.IOException;

public class UserPreferenceManager {
  
	private UserPreferenceManager() {}
   
	public static UserPreferenceManager getInstance(){ return null; }

	public void read (Preference p) {}   
   
	public void read(Preference p, Facility facility) {}  
   
	public void write (Preference p) throws	UnsupportedPreferenceException, IOException {}
   
	public void addUserPreferenceChangeListener (UserPreferenceChangeListener l) {}
   
	public void removeUserPreferenceChangeListener(UserPreferenceChangeListener l) {}

} 

