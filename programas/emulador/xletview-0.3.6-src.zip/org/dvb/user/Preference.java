/*

 This file is part of XleTView 
 Copyright (C) 2003 Martin Sved�n
 
 This is free software, and you are 
 welcome to redistribute it under 
 certain conditions;

 See LICENSE document for details.

*/


package org.dvb.user ;


public abstract class Preference {   
	protected Preference(){
	}

	public Preference (String name, String value) {
	}
  
	public Preference (String name, String value[]) {
	}
  
	public void add (String value) {
	}

	public void add( String values[]){
	}
  
	public void add (int position, String value) {
	}
  
	public String[] getFavourites () {
		return null;
	}
   
	public String getMostFavourite () {
		return null;
	} 
   
	public String getName () {
		return null;
	}
  
	public int getPosition (String value) {
		return 0;
	}
   
	public boolean hasValue () {
		return false;
	}
   
	public void remove (String value){
	}
	
	public void removeAll(){
	}
   
	public void setMostFavourite (String value) {
	}

	public String toString() {
		return null;
	}
}






