/*

 This file is part of XleTView 
 Copyright (C) 2003 Martin Sved�n
 
 This is free software, and you are 
 welcome to redistribute it under 
 certain conditions;

 See LICENSE document for details.

*/


package org.dvb.net.tuning;

public class DvbNetworkInterfaceSIUtil {

	private DvbNetworkInterfaceSIUtil()	{
	}
	
	public static org.dvb.si.SIDatabase getSIDatabase(org.davic.net.tuning.NetworkInterface ni) {
		return null;
	}
	
	public static org.davic.net.tuning.NetworkInterface   getNetworkInterface(org.dvb.si.SIDatabase sd) {
		return null;
	}
}

