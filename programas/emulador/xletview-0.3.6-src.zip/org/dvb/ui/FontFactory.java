/*

 This file is part of XleTView 
 Copyright (C) 2003 Martin Sved�n
 
 This is free software, and you are 
 welcome to redistribute it under 
 certain conditions;

 See LICENSE document for details.

*/


package org.dvb.ui;

import java.io.IOException;

public class FontFactory {
    
	public FontFactory() throws FontFormatException, IOException {
    }

	public FontFactory(java.net.URL u) throws IOException, FontFormatException {
    }

	public java.awt.Font createFont(String name, int style, int size) throws FontNotAvailableException,FontFormatException, IOException {
		return null;
    }

}
