/*

 This file is part of XleTView 
 Copyright (C) 2003 Martin Sved�n
 
 This is free software, and you are 
 welcome to redistribute it under 
 certain conditions;

 See LICENSE document for details.

*/


package org.havi.ui;


public class HFlatMatte implements HMatte{
    
    public HFlatMatte(){
    }

    public HFlatMatte(float data){
    }

    public void setMatteData(float data){
    }

    public float getMatteData(){
        return (1.0f);
    }
}
