/*

 This file is part of XleTView 
 Copyright (C) 2003 Martin Sved�n
 
 This is free software, and you are 
 welcome to redistribute it under 
 certain conditions;

 See LICENSE document for details.

*/


package org.havi.ui;

import java.awt.Image;
import java.awt.Point;


public class HImageMatte implements HMatte{
    
    public HImageMatte(){
    }
    
    public HImageMatte(Image data){
    }

    public void setMatteData(Image data){
    }

    public Image getMatteData(){
        return (null);
    }

    public void setOffset(Point p){
    }

    public Point getOffset(){
        return (null);
    }
}
