package br.lavid.xlet;
import java.awt.Color;
import java.awt.Font;

import org.dvb.event.*;
import org.dvb.ui.DVBColor;
import org.havi.ui.*;
import org.havi.ui.event.*;




public class TelaFinal implements UserEventListener {
	private HScene scene;
	private EventManager em;
	private int opcao;

	Imagens imagens;
	HIcon hi, hi2;
	HTextButton textBox;
	String nome = null;
	int x, dx;



	public TelaFinal(HScene scene, int opcao){
		this.scene=scene;
		em = EventManager.getInstance();
		imagens = new Imagens();
		this.opcao = opcao;

	}

	public void init() {

        hi = new HIcon(imagens.carregarImagem(Imagens.telaFinal),0,0,640,540);

        switch(opcao){

        case 1:
        	hi2 = new HIcon(imagens.carregarImagem(Imagens.imgJuliana),237,150,164,280);
        	nome = "Juliana Paes";
        	x = 220;
        	dx= 200;

        	break;

        case 2:
        	hi2 = new HIcon(imagens.carregarImagem(Imagens.imgGrazi),237,150,164,280);
        	nome = "Grazi";
        	x = 237;
        	dx = 164;
        	break;

        case 3:
        	hi2 = new HIcon(imagens.carregarImagem(Imagens.imgSheila),237,150,164,280);
        	nome = "Sheila Mello";
        	x = 220;
        	dx= 200;
        	break;

        case 4:
        	hi2 = new HIcon(imagens.carregarImagem(Imagens.imgAdriane),237,150,164,280);
        	nome = "Adriane Galisteu";
        	x = 204;
        	dx= 235;
        	break;
		}


		textBox = new HTextButton(nome,x,438,dx,30);
		textBox.setBackground(new DVBColor(255,255,255,0));
		textBox.setBackgroundMode(HVisible.BACKGROUND_FILL);
		textBox.setFont(new Font("Arial Black",Font.PLAIN,28));
		textBox.setForeground(new Color(223,106,42));
		//textBox.setHorizontalAlignment(HTextButton.HALIGN_LEFT);


		UserEventRepository uer = new UserEventRepository("TelaFinal");

		uer.addKey(HRcEvent.VK_ENTER);
		uer.addAllArrowKeys();
		em.addUserEventListener(this,uer);

		scene.add(textBox);
		scene.add(hi2);
		scene.add(hi);
		scene.repaint();
	}


	public void clear() {
		scene.removeAll();
		scene.repaint();
		em.removeUserEventListener(this);
	}

	public void userEventReceived(UserEvent e)
	{
		int type =e.getType();
		int code = e.getCode();

		if(type==HKeyEvent.KEY_PRESSED) {

			if (code== HRcEvent.VK_ENTER) {
				this.clear();

			}

		}
	}


}