package br.lavid.xlet;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;

import org.havi.ui.HComponent;

public class Imagens extends HComponent {

     public final static String telaInicial = "./imagens/telaInicial.png";
     public final static String tela1 = "./imagens/tela1.png";
     public final static String tela2 = "./imagens/tela2.png";
     public final static String tela3 = "./imagens/tela3.png";
     public final static String tela4 = "./imagens/tela4.png";
     public final static String telaFinal = "./imagens/telaFinal.png";
     public final static String imgSheila = "./imagens/m-sheila.png";
     public final static String imgAdriane = "./imagens/m-adriane.png";
     public final static String imgGrazi = "./imagens/m-grazi.png";
     public final static String imgJuliana = "./imagens/m-juliana.png";




     public Image carregarImagem(String caminho) {

 	   MediaTracker tracker = new MediaTracker(this);
	   Image img = Toolkit.getDefaultToolkit().getImage(caminho);
	   tracker.addImage(img, 0);
        try{
		tracker.waitForAll();
		return img;
	    }
	    catch(InterruptedException e) {
		   e.printStackTrace();
	    }
	   return null;
     }

}