package br.lavid.xlet;
import org.dvb.event.*;
import org.havi.ui.*;
import org.havi.ui.event.*;


public class TelaInicial implements UserEventListener {
	private HScene scene;
	private EventManager em;

	Imagens imagens;
	HIcon hi;

	public TelaInicial(HScene scene) {
		this.scene=scene;
		em = EventManager.getInstance();
		imagens = new Imagens();
	}

	public void init() {

        hi = new HIcon(imagens.carregarImagem(Imagens.telaInicial),0,0,640,540);

		UserEventRepository uer = new UserEventRepository("TelaInicial");

		uer.addKey(HRcEvent.VK_ENTER);
		em.addUserEventListener(this,uer);

		scene.add(hi);
		scene.repaint();
	}


	public void clear() {
		scene.removeAll();
		scene.repaint();
		em.removeUserEventListener(this);
	}

	public void userEventReceived(UserEvent e)
	{
		int type =e.getType();
		int code = e.getCode();

		if(type==HKeyEvent.KEY_PRESSED) {

			if (code== HRcEvent.VK_ENTER) {
				this.clear();
				Tela1 tela = new Tela1(scene);
				tela.init();
			}


		}
	}


}


