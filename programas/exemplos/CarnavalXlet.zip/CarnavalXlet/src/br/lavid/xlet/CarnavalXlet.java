package br.lavid.xlet;

import org.havi.ui.*;
import javax.tv.xlet.*;


public class CarnavalXlet implements Xlet {
	private XletContext context;

	private HScene scene;
	
	public CarnavalXlet() {
	}

	public void initXlet(XletContext xletContext) throws XletStateChangeException {
		System.out.println("initXlet");
		context = xletContext;
	}

	public void startXlet() throws XletStateChangeException {
		System.out.println("startXlet");
		HSceneFactory hsceneFactory = HSceneFactory.getInstance();
		scene = hsceneFactory.getFullScreenScene(HScreen.getDefaultHScreen()
				.getDefaultHGraphicsDevice());
		scene.setSize(640, 540);
		scene.setLayout(null);
		scene.setVisible(true);

		TelaInicial telaInicial = new TelaInicial(scene);
		telaInicial.init();


	}

	public void pauseXlet() {

	}

	public void destroyXlet(boolean flag) throws XletStateChangeException {
		System.out.println("destroyXlet");
		context.notifyDestroyed();
	}

}
