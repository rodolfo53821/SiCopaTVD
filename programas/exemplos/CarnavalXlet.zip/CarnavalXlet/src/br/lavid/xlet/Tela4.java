package br.lavid.xlet;
import org.dvb.event.*;
import org.havi.ui.*;
import org.havi.ui.event.*;




public class Tela4 implements UserEventListener {
	private HScene scene;
	private EventManager em;

	Imagens imagens;
	HIcon hi;



	public Tela4(HScene scene){
		this.scene=scene;
		em = EventManager.getInstance();
		imagens = new Imagens();

	}

	public void init() {

        hi = new HIcon(imagens.carregarImagem(Imagens.tela4),0,0,640,540);

		UserEventRepository uer = new UserEventRepository("Tela4");

		uer.addKey(HRcEvent.VK_ENTER);
		uer.addAllArrowKeys();
		em.addUserEventListener(this,uer);

		scene.add(hi);
		scene.repaint();
	}


	public void clear() {
		scene.removeAll();
		scene.repaint();
		em.removeUserEventListener(this);
	}

	public void userEventReceived(UserEvent e)
	{
		int type =e.getType();
		int code = e.getCode();

		if(type==HKeyEvent.KEY_PRESSED) {

			if (code== HRcEvent.VK_ENTER) {
				this.clear();
				TelaFinal telaf = new TelaFinal(scene,4);
				telaf.init();
			}
			else if (code== HRcEvent.VK_DOWN) {
				this.clear();
				Tela1 tela = new Tela1(scene);
				tela.init();
			}
			else if (code== HRcEvent.VK_UP) {
				this.clear();
				Tela3 tela3 = new Tela3(scene);
				tela3.init();
			}

		}
	}


}