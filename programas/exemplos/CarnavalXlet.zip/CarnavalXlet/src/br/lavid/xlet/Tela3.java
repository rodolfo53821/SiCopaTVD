package br.lavid.xlet;
import org.dvb.event.*;
import org.havi.ui.*;
import org.havi.ui.event.*;




public class Tela3 implements UserEventListener {
	private HScene scene;
	private EventManager em;

	Imagens imagens;
	HIcon hi;



	public Tela3(HScene scene){
		this.scene=scene;
		em = EventManager.getInstance();
		imagens = new Imagens();

	}

	public void init() {

        hi = new HIcon(imagens.carregarImagem(Imagens.tela3),0,0,640,540);

		UserEventRepository uer = new UserEventRepository("Tela3");

		uer.addKey(HRcEvent.VK_ENTER);
		uer.addAllArrowKeys();
		em.addUserEventListener(this,uer);

		scene.add(hi);
		scene.repaint();
	}


	public void clear() {
		scene.removeAll();
		scene.repaint();
		em.removeUserEventListener(this);
	}

	public void userEventReceived(UserEvent e)
	{
		int type =e.getType();
		int code = e.getCode();

		if(type==HKeyEvent.KEY_PRESSED) {

			if (code== HRcEvent.VK_ENTER) {
				this.clear();
				TelaFinal telaf = new TelaFinal(scene,3);
				telaf.init();
			}
			else if (code== HRcEvent.VK_DOWN) {
				this.clear();
				Tela4 tela = new Tela4(scene);
				tela.init();
			}
			else if (code== HRcEvent.VK_UP) {
				this.clear();
				Tela2 tela2 = new Tela2(scene);
				tela2.init();
			}

		}
	}


}