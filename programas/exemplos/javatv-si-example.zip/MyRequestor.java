import javax.tv.service.*;
import javax.tv.service.navigation.*;
import javax.tv.service.guide.*;

public class MyRequestor implements SIRequestor {

	EPGXlet parent;
	int queryType;
	int serviceIndex;
	
	// Constructor
	public MyRequestor(EPGXlet parent, int queryType) {
		this.parent = parent;
		this.queryType = queryType;
		this.serviceIndex = serviceIndex;
	}
	/**
	 * Inherited from SIRequestor
	 */
	public void notifySuccess(SIRetrievable[] result) {
		switch (queryType) {
			// Are we querying the details of the service?
			case EPGXlet.SERVICE_DETAILS_QUERY: {
				// This just takes the first element from the list - we should really examine 
				// all of them, but it's unlikely that the other elements would be useful
				parent.printServiceDetails((ServiceDetails) result[0]);
				break;
			}
			// Are we querying the details of the service?
			case EPGXlet.SERVICE_DESCRIPTION_QUERY: {
				// This just takes the first element from the list - we should really examine 
				// all of them, but it's unlikely that the other elements would be useful
				parent.printServiceDescription((ServiceDescription) result[0]);
				break;
			}
			// Are we querying the current event in the schedule?
			case EPGXlet.PROGRAM_SCHEDULE_NOW_QUERY: {
				parent.printEvent(EPGXlet.PROGRAM_SCHEDULE_NOW_QUERY, (ProgramEvent) result[0]);
				break;
			}
			// Are we querying the next event in the schedule?
			case EPGXlet.PROGRAM_SCHEDULE_NEXT_QUERY: {
				parent.printEvent(EPGXlet.PROGRAM_SCHEDULE_NEXT_QUERY, (ProgramEvent) result[0]);
				break;
			}
		}
		
		// Notify the main application that's waiting on the query result.
		synchronized(parent.requestFinished) {
				parent.requestFinished.notify();
		}

	}
	
	/**
	 * Inherited from SIRequestor
	 */
	public void notifyFailure(SIRequestFailureType reason) {

		// Notify the main application that's waiting on the query result.
		synchronized(parent.requestFinished) {
				parent.requestFinished.notify();
		}
		
		// we could handle errors nicely here, but I'm too lazy.
	}
}