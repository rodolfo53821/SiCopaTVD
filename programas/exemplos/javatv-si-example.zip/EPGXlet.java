import javax.tv.xlet.*;
import javax.tv.service.*;
import javax.tv.service.navigation.*;
import javax.tv.service.guide.*;
import javax.tv.service.selection.*;
import javax.tv.locator.*;

import javax.media.*;

/**
 * A very basic EPG implemented in pure JavaTV code.  This imposes some restrictions on it, especially 
 * related to the way services can be previewed
 *
 * This has NO user interface, except for some information printed to stdout.  I'm too lazy to write a 
 * nice UI for it since this is just an example
 */
public class EPGXlet implements Xlet {

	// Our xlet context
	private XletContext context;

	// The SI database
	SIManager siDatabase;

	// constants used to identify the type of query that we're making
	
	public static final int SERVICE_DETAILS_QUERY = 0; // service details
	public static final int SERVICE_DESCRIPTION_QUERY = 1; // service description
	public static final int PROGRAM_SCHEDULE_NEXT_QUERY = 2; // next event in the schedule
	public static final int PROGRAM_SCHEDULE_NOW_QUERY = 3; // current event in the schedule
	
	
	// Synchronisation object.  This lets us turn the asynchronous SI reqauests into something 
	// synchronous.  While this makes it slower, this isn't intended to be an optimised solution 
	// and makes the code slightly simpler since we only have to worry abotu one request at a 
	// time.
	public Object requestFinished;

	// Used by the callbacks to store the current event whenever we issue a request for the current event on a given service
	private ProgramEvent currentEvent;
	
	/******************************************************************************************
	 * Standard Xlet methods
	 */
	
	public EPGXlet()
	{
		// The constructor should contain nothing.  Any initialisation
		// should be done in the initXlet() method, or in the startXlet method
		// if it's time- or resource-intensive.  That way, the MHP middleware
		// can control when the initialisation happens in a much more predictable
		// way
	}

	/**
	 * Initialise the Xlet.  The context for this Xlet will get passed in to this
	 * method, and a reference to it should be stored in case it's needed later.
	 */
	public void initXlet(XletContext context) throws XletStateChangeException
	{
		// store a reference to the Xlet context that the Xlet is executing in
		this.context = context;
	}

    /**
     * Start the Xlet.  
     */
	public void startXlet() throws XletStateChangeException
	{
		// Do our SI stuff
		getServices();
	}

	/**
	 * Pause the Xlet.  
	 */
	public void pauseXlet()
	{
	}

	/**
	 * Stop the Xlet.  
	 */
	public void destroyXlet(boolean unconditional) throws XletStateChangeException
	{
	}	
	
	

	/******************************************************************************************
	 * Methods belonging to our Xlet
	 */
	 
	 
	/**
	 * Get the available digital TV services from the current SI Database
	 */
	private void getServices() {

		ServiceList services;
		
		// This is only used for synchronization, since we're doing some 
		// asynchronous calls.
		requestFinished = new Object();
		
		
		// get an SIManager instance
		siDatabase = SIManager.createInstance();

		// Filter the available services to get the list of Digital TV services.  Here we use a ServiceTypeFilter, 
		// but other types are available.
		ServiceFilter filter = new ServiceTypeFilter(ServiceType.DIGITAL_TV);
		services = siDatabase.filterServices(filter);
		
		//Now that we've got the list of services, do something with it
		
		// first, create an iterator to navigate the service list
		ServiceIterator iterator;
		iterator = services.createServiceIterator();
		
		// loop over the service list. nextService() will return the first service in the list the first time it's 
		// called, so we don't need to worry about missing anything
		while (iterator.hasNext()) {
			Service currentService;
			currentService = iterator.nextService();
			getSIInformation(currentService);
		}
	}

	/**
	 * Get SI information about a specific service
	 */
	private void getSIInformation(Service service) {
	
	 
	 		// Each SI Request has an SIRequestor object associated with it that will handle the response.
		SIRequestor requestor = new MyRequestor(this, this.SERVICE_DETAILS_QUERY);
		SIRequest request = service.retrieveDetails(requestor);
		
		// SI requests are asynchronous, and so we wait for the request to finish
		synchronized(requestFinished) {
			try {
				// The 'notify' that corresponds to this 'wait' takes place in
				// the requestor.
				requestFinished.wait();
			}
			catch (InterruptedException ie) {
				// Ignore the exception, since there's not much we can do about it.
			}
		}

		// The service details include the schedule information and service description, and 
		// this is retrieved by the callback that handles the result of the query for the 
		// details.
	}

	
	/** 
	 * Get the service description for the specified service
	 */
	 public void getServiceDescription(ServiceDetails serviceDetails) {

		// Retrieve the service description.
		SIRequestor requestor = new MyRequestor(this, this.SERVICE_DESCRIPTION_QUERY);
		SIRequest request = serviceDetails.retrieveServiceDescription(requestor);
		
		// SI requests are asynchronous, and so we wait for the request to finish
		synchronized(requestFinished) {
			try {
				// The 'notify' that corresponds to this 'wait' takes place in
				// the requestor.
				requestFinished.wait();
			}
			catch (InterruptedException ie) {
				// Ignore the exception, since there's not much we can do about it.
			}
		}
			// The value is printed out by the printServiceDescription() method when the result is available
	 }
	 
	/** 
	 * Get the schedule information for the specified service.  This is called from the 
	 * requestor as part of the callback when the service details are retrieved
	 */
	 public void getScheduleInfo(ServiceDetails serviceDetails) {

		ProgramSchedule schedule = serviceDetails.getProgramSchedule();

		// Retrieve the current event.
		SIRequestor nowRequestor = new MyRequestor(this, this.PROGRAM_SCHEDULE_NOW_QUERY);
		SIRequest request = schedule.retrieveCurrentProgramEvent(nowRequestor);
		
		// SI requests are asynchronous, and so we wait for the request to finish
		synchronized(requestFinished) {
			try {
				// The 'notify' that corresponds to this 'wait' takes place in
				// the requestor.
				requestFinished.wait();
			}
			catch (InterruptedException ie) {
				// Ignore the exception, since there's not much we can do about it.
			}
		}
		
		// Retrieve the next event in the same way.
		SIRequestor nextRequestor = new MyRequestor(this, this.PROGRAM_SCHEDULE_NOW_QUERY);
		try {
			request = schedule.retrieveNextProgramEvent(currentEvent, nextRequestor);
		}
		catch (SIException e) {
			//handle the exception
			System.out.println("SIException getting next event information");
		}
		
		
		synchronized(requestFinished) {
			try {
				requestFinished.wait();
			}
			catch (InterruptedException ie) {
				// Ignore the exception, since there's not much we can do about it.
			}
		}
			// The results are printed out by the printEvent() method when the result is available
	}
	 	 
	/** 
	 * Print the details of the service
	 */
	public void printServiceDetails(ServiceDetails details) {
		
		System.out.println("Service name: " + details.getLongName());
		
		// Get the service description
		getServiceDescription(details);
		
		// Get schedule information for the current service so that we can print it
		getScheduleInfo(details);
	}
	
	/** 
	 * Print the description for a service
	 */
	public void printServiceDescription(ServiceDescription desc) {
		System.out.println("Description:");
		System.out.println(desc.getServiceDescription());
	}
	 
	/**
	 * Print the schedule information for an event
	 */
	public void printEvent(int eventType, ProgramEvent event) {
		if (eventType == PROGRAM_SCHEDULE_NOW_QUERY) {
			System.out.print("current event: ");
			currentEvent = event;
		}
		else {
			System.out.print("next event: ");
		}
		System.out.println(event.getName());
		System.out.println("Start: " + event.getStartTime());
		System.out.println("End: " + event.getEndTime());
	}
	
	
	/**
	 * Preview a service.
	 *
	 */
	private void previewService(Service service) {

		// create a new JMF MediaLocator from the locator for the service.
		// We have to do this because they're not interoperable.
		Locator locator = service.getLocator();
		// Only toExternalForm() is guaranteed to return the URL.  toString() may not.
		MediaLocator mediaLoc = new MediaLocator(locator.toExternalForm());
		
		// Create and start the new Player
		Player player = null;
		try {
			player = Manager.createPlayer(mediaLoc);
		}
		catch (java.io.IOException e) {
				// handle this as we want to
		}
		catch (NoPlayerException npe) {
				System.out.println("no player for service!");
		}
		player.start();
		
	}
	
}