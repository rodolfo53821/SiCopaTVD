import java.awt.*;
import java.awt.event.*;
import javax.tv.xlet.*;
import org.havi.ui.*;
import org.havi.ui.event.*;

public class ExemploXlet implements Xlet, KeyListener {
    private XletContext context;
    private HScene scene;
    private HStaticText label1, label2;
    
    public ExemploXlet() {
        
        /* M�todo vazio */
        
    }
    
    public void initXlet(XletContext xletContext)
    throws XletStateChangeException {
        
        /* guardando o contexto... */
        this.context = xletContext;
        
    }
    
    public void startXlet()
    throws XletStateChangeException {
        
        HSceneFactory hsceneFactory = HSceneFactory.getInstance();
        
        scene = hsceneFactory.getFullScreenScene(HScreen.getDefaultHScreen().
        getDefaultHGraphicsDevice());
        scene.setSize(640, 480);
        
        scene.setLayout(null);
        scene.addKeyListener(this); //o pr�prio Xlet � o listener
        
        label1 = new HStaticText("Al\u00F4 MundoJava!", 35, 45, 660, 50,
        new Font("Tiresias", 1, 36),
        Color.red, Color.white,
        new HDefaultTextLayoutManager());
        label2 = new HStaticText("Controle Remoto", 100, 135, 500, 30,
        new Font("Tiresias", 1, 36),
        Color.red, Color.white,
        new HDefaultTextLayoutManager());
        
        scene.add(label1);
        scene.add(label2);
        scene.setVisible(true);
        scene.requestFocus();
        
    }
    
    
    public void pauseXlet() {
        
        /* M�todo vazio */
        
    }
    
    public void destroyXlet(boolean unconditional)
    throws XletStateChangeException {
        
        if (scene!=null) {
            scene.setVisible(false);
            scene.removeAll();
            scene = null;
        }
        context.notifyDestroyed();
        
    }
    
    /* M�todo de java.awt.event.KeyListener */
    public void keyTyped(KeyEvent keyevent) {
        /* M�todo vazio */
    }
    
    /* M�todo de java.awt.event.KeyListener */
    public void keyReleased(KeyEvent keyevent) {
        /* M�todo vazio */
    }
    
    /* M�todo de java.awt.event.KeyListener */
    public void keyPressed(KeyEvent e) {
        String mensagem = "";
        int codigo = e.getKeyCode();
                 /*
                  * 403 - vermelho
                  * 404 - verde
                  * 405 - amarelo
                  * 406 - azul
                  *
                  * 27 - exit
                  * * (asterisco) - 151
                  * # (grade) - 520
                  *
                  * seta para cima - 38
                  * seta para baixo - 40
                  * seta para esquerda - 37
                  * seta para direita - 39
                  * ok - 10
                  *
                  * n�meros - n�mero + 48 (ex. 2 � 50)
                  *
                  */
        
        switch (codigo) {
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
                mensagem += "Bot\u00E3o num\u00E9rico: "+(codigo-48);
                break;
            case 403:
                mensagem += "Bot\u00E3o Vermelho";
                break;
            case 404:
                mensagem += "Bot\u00E3o Verde";
                break;
            case 405:
                mensagem += "Bot\u00E3o Amarelo";
                break;
            case 406:
                mensagem += "Bot\u00E3o Azul";
                break;
            case 27:
                mensagem += "Bot\u00E3o EXIT";
                break;
            case 10:
                mensagem += "Bot\u00E3o OK";
                break;
            case 151:
                mensagem += "Bot\u00E3o Asterisco (*)";
                break;
            case 520:
                mensagem += "Bot\u00E3o grade (#)";
                break;
            case 38:
                mensagem += "Seta para cima";
                break;
            case 40:
                mensagem += "Seta para baixo";
                break;
            case 37:
                mensagem += "Seta para esquerda";
                break;
            case 39:
                mensagem += "Seta para direita";
                break;
            default:
                mensagem += "Al\u00F4 MundoJava!";
        }
        
        label2 = new HStaticText(mensagem, 100, 135, 500, 30,
        new Font("Tiresias", 1, 36),
        Color.blue, Color.white,
        new HDefaultTextLayoutManager());
        
        scene.removeAll();
        scene.add(label1);
        scene.add(label2);
        label2.repaint();
        scene.repaint();
        
    }
    
}
