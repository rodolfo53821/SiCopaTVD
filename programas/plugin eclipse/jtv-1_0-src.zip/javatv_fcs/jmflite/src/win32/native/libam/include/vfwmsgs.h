 // To add a message:
 //
 // The MessageId is the number of the message.
 // Accepted severities are 'Success' and 'Warning'.
 // Facility should be FACILITY_VFW.
 // The SymbolicName is the name used in the code to identify the message.
 // The text of a message starts the line after 'Language=' and
 // ends before a line with only a '.' in column one.
//
//  Values are 32 bit values layed out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +-+-+-+-+-+---------------------+-------------------------------+
//  |S|R|C|N|r|    Facility         |               Code            |
//  +-+-+-+-+-+---------------------+-------------------------------+
//
//  where
//
//      S - Severity - indicates success/fail
//
//          0 - Success
//          1 - Fail (COERROR)
//
//      R - reserved portion of the facility code, corresponds to NT's
//              second severity bit.
//
//      C - reserved portion of the facility code, corresponds to NT's
//              C field.
//
//      N - reserved portion of the facility code. Used to indicate a
//              mapped NT status value.
//
//      r - reserved portion of the facility code. Reserved for internal
//              use. Used to indicate HRESULT values that are not status
//              values, but are instead message ids for display strings.
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: VFW_E_INVALIDMEDIATYPE
//
// MessageText:
//
//  An invalid media type was specified.%0
//
#define VFW_E_INVALIDMEDIATYPE           ((HRESULT)0x80040200L)

//
// MessageId: VFW_E_INVALIDSUBTYPE
//
// MessageText:
//
//  An invalid media subtype was specified.%0
//
#define VFW_E_INVALIDSUBTYPE             ((HRESULT)0x80040201L)

//
// MessageId: VFW_E_NEED_OWNER
//
// MessageText:
//
//  This object can only be created as an aggregated object.%0
//
#define VFW_E_NEED_OWNER                 ((HRESULT)0x80040202L)

//
// MessageId: VFW_E_ENUM_OUT_OF_SYNC
//
// MessageText:
//
//  The enumerator has become invalid.%0
//
#define VFW_E_ENUM_OUT_OF_SYNC           ((HRESULT)0x80040203L)

//
// MessageId: VFW_E_ALREADY_CONNECTED
//
// MessageText:
//
//  At least one of the pins involved in the operation is already connected.%0
//
#define VFW_E_ALREADY_CONNECTED          ((HRESULT)0x80040204L)

//
// MessageId: VFW_E_FILTER_ACTIVE
//
// MessageText:
//
//  This operation cannot be performed because the filter is active.%0
//
#define VFW_E_FILTER_ACTIVE              ((HRESULT)0x80040205L)

//
// MessageId: VFW_E_NO_TYPES
//
// MessageText:
//
//  One of the specified pins supports no media types.%0
//
#define VFW_E_NO_TYPES                   ((HRESULT)0x80040206L)

//
// MessageId: VFW_E_NO_ACCEPTABLE_TYPES
//
// MessageText:
//
//  There is no common media type between these pins.%0
//
#define VFW_E_NO_ACCEPTABLE_TYPES        ((HRESULT)0x80040207L)

//
// MessageId: VFW_E_INVALID_DIRECTION
//
// MessageText:
//
//  Two pins of the same direction cannot be connected together.%0
//
#define VFW_E_INVALID_DIRECTION          ((HRESULT)0x80040208L)

//
// MessageId: VFW_E_NOT_CONNECTED
//
// MessageText:
//
//  The operation cannot be performed because the pins are not connected.%0
//
#define VFW_E_NOT_CONNECTED              ((HRESULT)0x80040209L)

//
// MessageId: VFW_E_NO_ALLOCATOR
//
// MessageText:
//
//  No sample buffer allocator is available.%0
//
#define VFW_E_NO_ALLOCATOR               ((HRESULT)0x8004020AL)

//
// MessageId: VFW_E_RUNTIME_ERROR
//
// MessageText:
//
//  A run-time error occurred.%0
//
#define VFW_E_RUNTIME_ERROR              ((HRESULT)0x8004020BL)

//
// MessageId: VFW_E_BUFFER_NOTSET
//
// MessageText:
//
//  No buffer space has been set.%0
//
#define VFW_E_BUFFER_NOTSET              ((HRESULT)0x8004020CL)

//
// MessageId: VFW_E_BUFFER_OVERFLOW
//
// MessageText:
//
//  The buffer is not big enough.%0
//
#define VFW_E_BUFFER_OVERFLOW            ((HRESULT)0x8004020DL)

//
// MessageId: VFW_E_BADALIGN
//
// MessageText:
//
//  An invalid alignment was specified.%0
//
#define VFW_E_BADALIGN                   ((HRESULT)0x8004020EL)

//
// MessageId: VFW_E_ALREADY_COMMITTED
//
// MessageText:
//
//  Cannot change allocated memory while the filter is active.%0
//
#define VFW_E_ALREADY_COMMITTED          ((HRESULT)0x8004020FL)

//
// MessageId: VFW_E_BUFFERS_OUTSTANDING
//
// MessageText:
//
//  One or more buffers are still active.%0
//
#define VFW_E_BUFFERS_OUTSTANDING        ((HRESULT)0x80040210L)

//
// MessageId: VFW_E_NOT_COMMITTED
//
// MessageText:
//
//  Cannot allocate a sample when the allocator is not active.%0
//
#define VFW_E_NOT_COMMITTED              ((HRESULT)0x80040211L)

//
// MessageId: VFW_E_SIZENOTSET
//
// MessageText:
//
//  Cannot allocate memory because no size has been set.%0
//
#define VFW_E_SIZENOTSET                 ((HRESULT)0x80040212L)

//
// MessageId: VFW_E_NO_CLOCK
//
// MessageText:
//
//  Cannot lock for synchronization because no clock has been defined.%0
//
#define VFW_E_NO_CLOCK                   ((HRESULT)0x80040213L)

//
// MessageId: VFW_E_NO_SINK
//
// MessageText:
//
//  Quality messages could not be sent because no quality sink has been defined.%0
//
#define VFW_E_NO_SINK                    ((HRESULT)0x80040214L)

//
// MessageId: VFW_E_NO_INTERFACE
//
// MessageText:
//
//  A required interface  has not been implemented.%0
//
#define VFW_E_NO_INTERFACE               ((HRESULT)0x80040215L)

//
// MessageId: VFW_E_NOT_FOUND
//
// MessageText:
//
//  An object or name was not found.%0
//
#define VFW_E_NOT_FOUND                  ((HRESULT)0x80040216L)

//
// MessageId: VFW_E_CANNOT_CONNECT
//
// MessageText:
//
//  No combination of intermediate filters could be found to make the connection.%0
//
#define VFW_E_CANNOT_CONNECT             ((HRESULT)0x80040217L)

//
// MessageId: VFW_E_CANNOT_RENDER
//
// MessageText:
//
//  No combination of filters could be found to render the stream.%0
//
#define VFW_E_CANNOT_RENDER              ((HRESULT)0x80040218L)

//
// MessageId: VFW_E_CHANGING_FORMAT
//
// MessageText:
//
//  Could not change formats dynamically.%0
//
#define VFW_E_CHANGING_FORMAT            ((HRESULT)0x80040219L)

//
// MessageId: VFW_E_NO_COLOR_KEY_SET
//
// MessageText:
//
//  No color key has been set.%0
//
#define VFW_E_NO_COLOR_KEY_SET           ((HRESULT)0x8004021AL)

//
// MessageId: VFW_E_NOT_OVERLAY_CONNECTION
//
// MessageText:
//
//  Current pin connection is not using the IOverlay transport.%0
//
#define VFW_E_NOT_OVERLAY_CONNECTION     ((HRESULT)0x8004021BL)

//
// MessageId: VFW_E_NOT_SAMPLE_CONNECTION
//
// MessageText:
//
//  Current pin connection is not using the IMemInputPin transport.%0
//
#define VFW_E_NOT_SAMPLE_CONNECTION      ((HRESULT)0x8004021CL)

//
// MessageId: VFW_E_PALETTE_SET
//
// MessageText:
//
//  Setting a color key would conflict with the palette already set.%0
//
#define VFW_E_PALETTE_SET                ((HRESULT)0x8004021DL)

//
// MessageId: VFW_E_COLOR_KEY_SET
//
// MessageText:
//
//  Setting a palette would conflict with the color key already set.%0
//
#define VFW_E_COLOR_KEY_SET              ((HRESULT)0x8004021EL)

//
// MessageId: VFW_E_NO_COLOR_KEY_FOUND
//
// MessageText:
//
//  No matching color key is available.%0
//
#define VFW_E_NO_COLOR_KEY_FOUND         ((HRESULT)0x8004021FL)

//
// MessageId: VFW_E_NO_PALETTE_AVAILABLE
//
// MessageText:
//
//  No palette is available.%0
//
#define VFW_E_NO_PALETTE_AVAILABLE       ((HRESULT)0x80040220L)

//
// MessageId: VFW_E_NO_DISPLAY_PALETTE
//
// MessageText:
//
//  Display does not use a palette.%0
//
#define VFW_E_NO_DISPLAY_PALETTE         ((HRESULT)0x80040221L)

//
// MessageId: VFW_E_TOO_MANY_COLORS
//
// MessageText:
//
//  Too many colors for the current display settings.%0
//
#define VFW_E_TOO_MANY_COLORS            ((HRESULT)0x80040222L)

//
// MessageId: VFW_E_STATE_CHANGED
//
// MessageText:
//
//  The state changed while waiting to process the sample.%0
//
#define VFW_E_STATE_CHANGED              ((HRESULT)0x80040223L)

//
// MessageId: VFW_E_NOT_STOPPED
//
// MessageText:
//
//  The operation could not be performed because the filter is not stopped.%0
//
#define VFW_E_NOT_STOPPED                ((HRESULT)0x80040224L)

//
// MessageId: VFW_E_NOT_PAUSED
//
// MessageText:
//
//  The operation could not be performed because the filter is not paused.%0
//
#define VFW_E_NOT_PAUSED                 ((HRESULT)0x80040225L)

//
// MessageId: VFW_E_NOT_RUNNING
//
// MessageText:
//
//  The operation could not be performed because the filter is not running.%0
//
#define VFW_E_NOT_RUNNING                ((HRESULT)0x80040226L)

//
// MessageId: VFW_E_WRONG_STATE
//
// MessageText:
//
//  The operation could not be performed because the filter is in the wrong state.%0
//
#define VFW_E_WRONG_STATE                ((HRESULT)0x80040227L)

//
// MessageId: VFW_E_START_TIME_AFTER_END
//
// MessageText:
//
//  The sample start time is after the sample end time.%0
//
#define VFW_E_START_TIME_AFTER_END       ((HRESULT)0x80040228L)

//
// MessageId: VFW_E_INVALID_RECT
//
// MessageText:
//
//  The supplied rectangle is invalid.%0
//
#define VFW_E_INVALID_RECT               ((HRESULT)0x80040229L)

//
// MessageId: VFW_E_TYPE_NOT_ACCEPTED
//
// MessageText:
//
//  This pin cannot use the supplied media type.%0
//
#define VFW_E_TYPE_NOT_ACCEPTED          ((HRESULT)0x8004022AL)

//
// MessageId: VFW_E_SAMPLE_REJECTED
//
// MessageText:
//
//  This sample cannot be rendered.%0
//
#define VFW_E_SAMPLE_REJECTED            ((HRESULT)0x8004022BL)

//
// MessageId: VFW_E_SAMPLE_REJECTED_EOS
//
// MessageText:
//
//  This sample cannot be rendered because the  end of the stream has been reached.%0
//
#define VFW_E_SAMPLE_REJECTED_EOS        ((HRESULT)0x8004022CL)

//
// MessageId: VFW_E_DUPLICATE_NAME
//
// MessageText:
//
//  An attempt to add a filter with a duplicate name failed.%0
//
#define VFW_E_DUPLICATE_NAME             ((HRESULT)0x8004022DL)

//
// MessageId: VFW_S_DUPLICATE_NAME
//
// MessageText:
//
//  An attempt to add a filter with a duplicate name succeeded with a modified name.%0
//
#define VFW_S_DUPLICATE_NAME             ((HRESULT)0x0004022DL)

//
// MessageId: VFW_E_TIMEOUT
//
// MessageText:
//
//  A time-out has expired.%0
//
#define VFW_E_TIMEOUT                    ((HRESULT)0x8004022EL)

//
// MessageId: VFW_E_INVALID_FILE_FORMAT
//
// MessageText:
//
//  The file format is invalid.%0
//
#define VFW_E_INVALID_FILE_FORMAT        ((HRESULT)0x8004022FL)

//
// MessageId: VFW_E_ENUM_OUT_OF_RANGE
//
// MessageText:
//
//  The list has already been exhausted.%0
//
#define VFW_E_ENUM_OUT_OF_RANGE          ((HRESULT)0x80040230L)

//
// MessageId: VFW_E_CIRCULAR_GRAPH
//
// MessageText:
//
//  The filter graph is circular.%0
//
#define VFW_E_CIRCULAR_GRAPH             ((HRESULT)0x80040231L)

//
// MessageId: VFW_E_NOT_ALLOWED_TO_SAVE
//
// MessageText:
//
//  Updates are not allowed in this state.%0
//
#define VFW_E_NOT_ALLOWED_TO_SAVE        ((HRESULT)0x80040232L)

//
// MessageId: VFW_E_TIME_ALREADY_PASSED
//
// MessageText:
//
//  An attempt was made to queue a command for a time in the past.%0
//
#define VFW_E_TIME_ALREADY_PASSED        ((HRESULT)0x80040233L)

//
// MessageId: VFW_E_ALREADY_CANCELLED
//
// MessageText:
//
//  The queued command has already been canceled.%0
//
#define VFW_E_ALREADY_CANCELLED          ((HRESULT)0x80040234L)

//
// MessageId: VFW_E_CORRUPT_GRAPH_FILE
//
// MessageText:
//
//  Cannot render the file because it is corrupt.%0
//
#define VFW_E_CORRUPT_GRAPH_FILE         ((HRESULT)0x80040235L)

//
// MessageId: VFW_E_ADVISE_ALREADY_SET
//
// MessageText:
//
//  An overlay advise link already exists.%0
//
#define VFW_E_ADVISE_ALREADY_SET         ((HRESULT)0x80040236L)

//
// MessageId: VFW_S_STATE_INTERMEDIATE
//
// MessageText:
//
//  The state transition has not completed.%0
//
#define VFW_S_STATE_INTERMEDIATE         ((HRESULT)0x00040237L)

//
// MessageId: VFW_E_NO_MODEX_AVAILABLE
//
// MessageText:
//
//  No full-screen modes are available.%0
//
#define VFW_E_NO_MODEX_AVAILABLE         ((HRESULT)0x80040238L)

//
// MessageId: VFW_E_NO_ADVISE_SET
//
// MessageText:
//
//  This Advise cannot be canceled because it was not successfully set.%0
//
#define VFW_E_NO_ADVISE_SET              ((HRESULT)0x80040239L)

//
// MessageId: VFW_E_NO_FULLSCREEN
//
// MessageText:
//
//  A full-screen mode is not available.%0
//
#define VFW_E_NO_FULLSCREEN              ((HRESULT)0x8004023AL)

//
// MessageId: VFW_E_IN_FULLSCREEN_MODE
//
// MessageText:
//
//  Cannot call IVideoWindow methods while in full-screen mode.%0
//
#define VFW_E_IN_FULLSCREEN_MODE         ((HRESULT)0x8004023BL)

//
// MessageId: VFW_E_UNKNOWN_FILE_TYPE
//
// MessageText:
//
//  The media type of this file is not recognized.%0
//
#define VFW_E_UNKNOWN_FILE_TYPE          ((HRESULT)0x80040240L)

//
// MessageId: VFW_E_CANNOT_LOAD_SOURCE_FILTER
//
// MessageText:
//
//  The source filter for this file could not be loaded.%0
//
#define VFW_E_CANNOT_LOAD_SOURCE_FILTER  ((HRESULT)0x80040241L)

//
// MessageId: VFW_S_PARTIAL_RENDER
//
// MessageText:
//
//  Some of the streams in this movie are in an unsupported format.%0
//
#define VFW_S_PARTIAL_RENDER             ((HRESULT)0x00040242L)

//
// MessageId: VFW_E_FILE_TOO_SHORT
//
// MessageText:
//
//  A file appeared to be incomplete.%0
//
#define VFW_E_FILE_TOO_SHORT             ((HRESULT)0x80040243L)

//
// MessageId: VFW_E_INVALID_FILE_VERSION
//
// MessageText:
//
//  The version number of the file is invalid.%0
//
#define VFW_E_INVALID_FILE_VERSION       ((HRESULT)0x80040244L)

//
// MessageId: VFW_S_SOME_DATA_IGNORED
//
// MessageText:
//
//  The file contained some property settings that were not used.%0
//
#define VFW_S_SOME_DATA_IGNORED          ((HRESULT)0x00040245L)

//
// MessageId: VFW_S_CONNECTIONS_DEFERRED
//
// MessageText:
//
//  Some connections have failed and have been deferred.%0
//
#define VFW_S_CONNECTIONS_DEFERRED       ((HRESULT)0x00040246L)

//
// MessageId: VFW_E_INVALID_CLSID
//
// MessageText:
//
//  This file is corrupt: it contains an invalid class identifier.%0
//
#define VFW_E_INVALID_CLSID              ((HRESULT)0x80040247L)

//
// MessageId: VFW_E_INVALID_MEDIA_TYPE
//
// MessageText:
//
//  This file is corrupt: it contains an invalid media type.%0
//
#define VFW_E_INVALID_MEDIA_TYPE         ((HRESULT)0x80040248L)

 // Message id from WINWarning.H
//
// MessageId: VFW_E_BAD_KEY
//
// MessageText:
//
//  A registry entry is corrupt.%0
//
#define VFW_E_BAD_KEY                    ((HRESULT)0x800403F2L)

 // Message id from WINWarning.H
//
// MessageId: VFW_S_NO_MORE_ITEMS
//
// MessageText:
//
//  The end of the list has been reached.%0
//
#define VFW_S_NO_MORE_ITEMS              ((HRESULT)0x00040103L)

//
// MessageId: VFW_E_SAMPLE_TIME_NOT_SET
//
// MessageText:
//
//  No time stamp has been set for this sample.%0
//
#define VFW_E_SAMPLE_TIME_NOT_SET        ((HRESULT)0x80040249L)

//
// MessageId: VFW_S_RESOURCE_NOT_NEEDED
//
// MessageText:
//
//  The resource specified is no longer needed.%0
//
#define VFW_S_RESOURCE_NOT_NEEDED        ((HRESULT)0x00040250L)

//
// MessageId: VFW_E_MEDIA_TIME_NOT_SET
//
// MessageText:
//
//  No media time stamp has been set for this sample.%0
//
#define VFW_E_MEDIA_TIME_NOT_SET         ((HRESULT)0x80040251L)

//
// MessageId: VFW_E_NO_TIME_FORMAT_SET
//
// MessageText:
//
//  No media time format has been selected.%0
//
#define VFW_E_NO_TIME_FORMAT_SET         ((HRESULT)0x80040252L)

//
// MessageId: VFW_E_MONO_AUDIO_HW
//
// MessageText:
//
//  Cannot change balance because audio device is mono only.%0
//
#define VFW_E_MONO_AUDIO_HW              ((HRESULT)0x80040253L)

//
// MessageId: VFW_S_MEDIA_TYPE_IGNORED
//
// MessageText:
//
//  A connection could not be made with the media type in the persistent graph,%0
//  but has been made with a negotiated media type.%0
//
#define VFW_S_MEDIA_TYPE_IGNORED         ((HRESULT)0x00040254L)

//
// MessageId: VFW_E_NO_DECOMPRESSOR
//
// MessageText:
//
//  Cannot play back the video stream: no suitable decompressor could be found.%0
//
#define VFW_E_NO_DECOMPRESSOR            ((HRESULT)0x80040255L)

//
// MessageId: VFW_E_NO_AUDIO_HARDWARE
//
// MessageText:
//
//  Cannot play back the audio stream: no audio hardware is available, or the hardware is not responding.%0
//
#define VFW_E_NO_AUDIO_HARDWARE          ((HRESULT)0x80040256L)

//
// MessageId: VFW_S_VIDEO_NOT_RENDERED
//
// MessageText:
//
//  Cannot play back the video stream: no suitable decompressor could be found.%0
//
#define VFW_S_VIDEO_NOT_RENDERED         ((HRESULT)0x00040257L)

//
// MessageId: VFW_S_AUDIO_NOT_RENDERED
//
// MessageText:
//
//  Cannot play back the audio stream: no audio hardware is available.%0
//
#define VFW_S_AUDIO_NOT_RENDERED         ((HRESULT)0x00040258L)

//
// MessageId: VFW_E_RPZA
//
// MessageText:
//
//  Cannot play back the video stream: format 'RPZA' is not supported.%0
//
#define VFW_E_RPZA                       ((HRESULT)0x80040259L)

//
// MessageId: VFW_S_RPZA
//
// MessageText:
//
//  Cannot play back the video stream: format 'RPZA' is not supported.%0
//
#define VFW_S_RPZA                       ((HRESULT)0x0004025AL)

//
// MessageId: VFW_E_PROCESSOR_NOT_SUITABLE
//
// MessageText:
//
//  ActiveMovie cannot play MPEG movies on this processor.%0
//
#define VFW_E_PROCESSOR_NOT_SUITABLE     ((HRESULT)0x8004025BL)

//
// MessageId: VFW_E_UNSUPPORTED_AUDIO
//
// MessageText:
//
//  Cannot play back the audio stream: the audio format is not supported.%0
//
#define VFW_E_UNSUPPORTED_AUDIO          ((HRESULT)0x8004025CL)

//
// MessageId: VFW_E_UNSUPPORTED_VIDEO
//
// MessageText:
//
//  Cannot play back the video stream: the video format is not supported.%0
//
#define VFW_E_UNSUPPORTED_VIDEO          ((HRESULT)0x8004025DL)

//
// MessageId: VFW_E_MPEG_NOT_CONSTRAINED
//
// MessageText:
//
//  ActiveMovie cannot play this video stream because it falls outside the constrained standard.%0
//
#define VFW_E_MPEG_NOT_CONSTRAINED       ((HRESULT)0x8004025EL)

//
// MessageId: VFW_E_NOT_IN_GRAPH
//
// MessageText:
//
//  Cannot perform the requested function on an object that is not in the filter graph.%0
//
#define VFW_E_NOT_IN_GRAPH               ((HRESULT)0x8004025FL)

//
// MessageId: VFW_S_ESTIMATED
//
// MessageText:
//
//  The value returned had to be estimated.  It's accuracy can not be guaranteed.%0
//
#define VFW_S_ESTIMATED                  ((HRESULT)0x00040260L)

//
// MessageId: VFW_E_NO_TIME_FORMAT
//
// MessageText:
//
//  Cannot get or set time related information on an object that is using a time format of TIME_FORMAT_NONE.%0
//
#define VFW_E_NO_TIME_FORMAT             ((HRESULT)0x80040261L)

//
// MessageId: VFW_E_READ_ONLY
//
// MessageText:
//
//  The connection cannot be made because the stream is read only and the filter alters the data.%0
//
#define VFW_E_READ_ONLY                  ((HRESULT)0x80040262L)

//
// MessageId: VFW_S_RESERVED
//
// MessageText:
//
//  This success code is reserved for internal purposes within ActiveMovie.%0
//
#define VFW_S_RESERVED                   ((HRESULT)0x00040263L)

//
// MessageId: VFW_E_BUFFER_UNDERFLOW
//
// MessageText:
//
//  The buffer is not full enough.%0
//
#define VFW_E_BUFFER_UNDERFLOW           ((HRESULT)0x80040264L)

//
// MessageId: VFW_E_UNSUPPORTED_STREAM
//
// MessageText:
//
//  Cannot play back the file.  The format is not supported.%0
//
#define VFW_E_UNSUPPORTED_STREAM         ((HRESULT)0x80040265L)

